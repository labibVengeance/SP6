from flask import Blueprint, render_template, request, redirect, url_for, flash
from . import db, bcrypt
from .models import User
from flask import session

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')

        # Add user to the database
        user = User(username=username, email=email, password=password)
        db.session.add(user)
        db.session.commit()

        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('main.login'))
    return render_template('register.html')

@main.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()

        if user and bcrypt.check_password_hash(user.password, password):
            # Set user session
            session['user_id'] = user.id
            session['username'] = user.username
            session['email'] = user.email

            flash('Login successful!', 'success')
            return redirect(url_for('main.index'))
        else:
            flash('Invalid email or password.', 'danger')

    return render_template('login.html')
@main.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('main.index'))
@main.route('/account')
def account():
    if not session.get('user_id'):
        flash('You need to log in to access this page.', 'warning')
        return redirect(url_for('main.login'))
    
    # Fetch user details from the database
    user = User.query.get(session['user_id'])  # Assuming you have a User model

    # Create the user_info dictionary with all fields
    user_info = {
        "username": user.username,
        "email": user.email,
        "phone": user.phone,
        "bio": user.bio
    }

    return render_template('account.html', user=user_info)

@main.route('/edit_profile', methods=['POST'])
def edit_profile():
    if not session.get('user_id'):
        flash('You need to log in to edit your profile.', 'warning')
        return redirect(url_for('main.login'))

    user = User.query.get(session['user_id'])

    # Update fields only if provided
    user.username = request.form.get('username', user.username)
    user.email = request.form.get('email', user.email)
    user.phone = request.form.get('phone', user.phone)  # New phone field
    user.bio = request.form.get('bio', user.bio)        # New bio field

    if request.form.get('password'):
        user.password = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')

    db.session.commit()
    flash('Profile updated successfully!', 'success')
    return redirect(url_for('main.account'))
