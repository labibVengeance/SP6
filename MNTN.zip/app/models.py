from . import db

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(15), nullable=True)  # Optional field
    bio = db.Column(db.Text, nullable=True)         # Optional field
    created_at = db.Column(db.DateTime, server_default=db.func.now())